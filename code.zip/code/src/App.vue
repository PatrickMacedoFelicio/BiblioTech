<script setup lang="ts">
import { RouterLink, RouterView } from 'vue-router'
import NavSidebar from './Components/layout/NavSidebar.vue'
</script>

<template>

  <RouterView />
</template>

<style scoped>
</style>
