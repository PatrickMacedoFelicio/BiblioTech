<template>
  <h1>Área de realizar emprestimos</h1>
</template>

<script lang="ts">
import { defineComponent } from "vue";

export default defineComponent({
  name: 'IndexView'
});
</script>