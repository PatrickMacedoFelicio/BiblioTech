declare module 'vue-the-mask' {
  import { Directive } from 'vue'
  export const mask: Directive
}
